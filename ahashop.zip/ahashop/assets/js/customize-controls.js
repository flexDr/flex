/**
 * Scripts within the customizer controls window.
 *
 * Contextually shows the color hue control and informs the preview
 * when users open or close the front page sections section.
 */

(function($) {
    wp.customize.bind( 'ready', function() {
        // Only show footer columns number when show footer columns.
        wp.customize( 'footer_columns', function( setting ) {
            wp.customize.control( 'footer_columns_number', function( control ) {
                var visibility = function() {
                    if ( setting.get() ) {
                        control.container.slideDown( 180 );
                    } else {
                        control.container.slideUp( 180 );
                    }
                };

                visibility();
                setting.bind( visibility );
            });

            for( i=1;i<=6;i++){
                wp.customize.control( 'footer_columns_width_'+i, function( control ) {
                    var visibility = function() {
                        if ( setting.get() ) {
                            control.container.slideDown( 180 );
                        } else {
                            control.container.slideUp( 180 );
                        }
                    };

                    visibility();
                    setting.bind( visibility );
                });
            }
        });

        // Only show logo text custom.
        wp.customize( 'enable_logo_text', function( setting ) {
            var arr_id = ['header_logo_text','logo_text_font_size','ahashop_logo_text_font_google','logo_text_font_color','logo_text_font_type'];
            arr_id.forEach(logo_id_option);

            function logo_id_option(item, index) {
                wp.customize.control( item, function( control ) {
                    var visibility = function() {
                        if ( setting.get() ) {
                            control.container.slideDown( 180 );
                        } else {
                            control.container.slideUp( 180 );
                        }
                    };

                    visibility();
                    setting.bind( visibility );
                });
            }
        });

        // Header Notify.
        wp.customize( 'show_notify', function( setting ) {
            var arr_id = ['notify_text','notify_min_height','notify_color','notify_bg_color'];
            arr_id.forEach(notify_id_option);

            function notify_id_option(item, index) {
                wp.customize.control( item, function( control ) {
                    var visibility = function() {
                        if ( setting.get() ) {
                            control.container.slideDown( 180 );
                        } else {
                            control.container.slideUp( 180 );
                        }
                    };

                    visibility();
                    setting.bind( visibility );
                });
            }
        });

        // Only show the color hue control when there's a custom color scheme.
        /*wp.customize( 'colorscheme', function( setting ) {
            wp.customize.control( 'colorscheme_hue', function( control ) {
                var visibility = function() {
                    if ( 'custom' === setting.get() ) {
                        control.container.slideDown( 180 );
                    } else {
                        control.container.slideUp( 180 );
                    }
                };

                visibility();
                setting.bind( visibility );
            });
        });*/

        // Detect when the front page sections section is expanded (or closed) so we can adjust the preview accordingly.
        /*wp.customize.section( 'theme_options', function( section ) {
            section.expanded.bind( function( isExpanding ) {

                // Value of isExpanding will = true if you're entering the section, false if you're leaving it.
                wp.customize.previewer.send( 'section-highlight', { expanded: isExpanding });
            } );
        } );*/
    });

    wp.customize.bind( 'ready', function() {

    });
})( jQuery );
