
(function($) {
    $(document).ready(() => {
        new OTFControlGoogleFont($);
        wp.customize.previewer.bind('refresh-frame', () => {
            wp.customize.previewer.refresh();
        });
        wp.customize.previewer.bind('opal-save-and-reload', () => {
            wp.customize.previewer.save().then(() => {
                wp.customize.previewer.refresh();
                let iframe = $('#customize-preview iframe').get(0);
                iframe.src = iframe.src;
            });
        });
    });
})( jQuery );