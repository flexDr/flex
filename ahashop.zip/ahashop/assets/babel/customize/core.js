class OTFCustomizeCore{

    /**
     * @param $container
     *
     * @return string
     */
    static getId($container) {
        return $container.data('id');
    }

    /**
     * @param $container
     * @param newValue
     */
    static setValue($container, newValue){
        wp.customize.control(this.getId($container)).setting.set(newValue);
    }
}