class OTFControlGoogleFont {
    container         = '[otf-fonts-control]';
    googleFont        = '.otf-customize-google-fonts';
    googleFontWeight  = '.otf-font-weight select';
    googleFontSubsets = '.otf-font-subsets select';
    $;

    constructor(jQuery) {
        $=jQuery;
        $(`#customize-theme-controls ${this.container}`).each((index, element) => {
            let $container = $(element);
            this.initSelect2($container.find(this.googleFont));
            this.initFontExtend($container.find(this.googleFontWeight));
            this.initFontExtend($container.find(this.googleFontSubsets));
        });
    }

    initFontExtend($select) {
        $select.val($select.data('value'));
        $select.on('change', () => {
            this.setValue($select.closest(this.container));
        });
    }

    initSelect2($select2) {
        this.initFontStyleHtml($select2);
        $select2.select2_custom({
            templateResult   : this.renderTemplate,
            templateSelection: this.renderTemplate
        }).on('change', () => {
            this.initFontStyleHtml($select2);
            this.setValue($select2.closest(this.container));
        });
    }

    setValue($container) {
        let newValue = {
            family    : $container.find(`${this.googleFont} option:selected`).attr('value'),
            subsets   : $container.find(`${this.googleFontSubsets} option:selected`).attr('value'),
            fontWeight: $container.find(`${this.googleFontWeight} option:selected`).attr('value')
        };
        OTFCustomizeCore.setValue($container, newValue);
    }

    initFontStyleHtml($select2) {
        //console.log($select2);
        let $parent        = $select2.closest(this.container);
        let info           = $select2.children('option:selected').data('info');
        let htmlFontWeight = '';
        let htmlSubsets    = '';
        if (typeof info === 'object') {
            if (info.variants) {
                htmlFontWeight += '<option value="400">400</option>';
                for (let variant of info.variants) {
                    htmlFontWeight += `<option value="${variant}">${variant}</option>`;
                }
            }
            if (info.subsets) {
                for (let subset of info.subsets) {
                    htmlSubsets += `<option value="${subset}">${subset}</option>`;
                }
            }
        }
        $parent.find('.otf-font-weight select').html(htmlFontWeight);
        $parent.find('.otf-font-subsets select').html(htmlSubsets);
    }

    renderTemplate(state) {
        if (!state.id) {
            return state.text;
        }
        let id = state.id.toLocaleLowerCase().replace(/\s+/, '-');
        return $(`<span>${state.text}</span><span class="otf-font ${id}"></span>`);
    }
}

