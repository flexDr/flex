<?php
/**
 * Template part default layout
 *
 * @package Ahashop
 */

ahashop_notify();

//ahashop_top_bar();

get_template_part( 'template-parts/header/navigation-menu-on-logo' );

