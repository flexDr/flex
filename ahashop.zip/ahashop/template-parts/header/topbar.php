<?php
/**
 * Template part for topbar
 *
 * @package Ahashop
 */

$ahashop_header_layout = ahashop_option( 'header_layout' );
$ahashop_container = 'container';
if ( ! ahashop_option( 'header_container' ) ) {
    $ahashop_container = 'container-fluid';
}
?>
<div class="top-bar hidden-sm hidden-xs">
	<div class="<?php echo esc_attr($ahashop_container); ?>">
		<div class="top-bar-line">
			<div class="row">
				<div class="top-bar-links">
					<div class="col-sm-6">
						<?php
                        if( $ahashop_header_layout == 'aside-menu' ){
                            /**
                             * Hook ahashop_before_navbar_logo
                             *
                             * @hooked ahashop_header_search() - 10
                             */
                            do_action( 'ahashop_before_navbar_logo' );
                        }else{
                            wp_nav_menu( array(
                                'theme_location' => 'top-menu',
                                'fallback_cb'    => false,
                                'container'      => '',
                                'menu_class'     => 'top-bar-acc',
                            ) );
                        }

						?>
					</div>

					<div class="col-sm-6 text-right">
						<ul class="top-bar-currency-language">
							<li>
								<?php ahashop_social_follow(); ?>
							</li>
						</ul>
					</div>

				</div>
			</div>
		</div>

	</div>
</div> <!-- end top bar -->
