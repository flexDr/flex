<?php
/**
 * Template part for Notify
 *
 * @package Ahashop
 */

$ahashop_notify_text = ahashop_option('notify_text');
$ahashop_notify_link = ahashop_option('notify_link');

$ahashop_container = 'container';
if ( ! ahashop_option( 'header_container' ) ) {
    $ahashop_container = 'container-fluid';
}

if( $ahashop_notify_text != '' ):
?>
<div class="header-notify hidden-sm hidden-xs js-header-notify">
	<div class="notify-inner">
        <div class="<?php echo esc_attr($ahashop_container); ?>">
            <div class="notify-content text-center">
            	<p>
                <?php
                    echo wp_kses_post($ahashop_notify_text);
                ?>
                </p>
            </div>
        </div>
        <span class="notify-close js-notify-close"><i class="fa fa-times"></i></span>
	</div>
</div> <!-- end top bar -->
<?php
endif;
