<?php
/**
 * Template part for header mini cart
 *
 * @package Ahashop
 */

?>
<div class="nav-cart-hover">
	<div class="nav-cart right">
		<div class="nav-cart-outer">
			<div class="nav-cart-inner">
				<a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="nav-cart-icon"><?php echo absint( WC()->cart->get_cart_contents_count() ); ?></a>
			</div>
		</div>

		<div class="nav-cart-container">
            <?php 
            if ( class_exists( 'WC_Widget_Cart' ) ) {
                the_widget( 'WC_Widget_Cart' );
            } 
            ?>
		</div>
	</div>
	<div class="menu-cart-amount right">
		<?php ahashop_cart_link(); ?>
	</div>
</div>
