<?php
/**
 * Template for post qoute
 *
 * @package Ahashop
 */

?>
<!-- blockquote post -->
<article <?php post_class( 'entry-item' ); ?>>
	<div class="entry blockquote">
		<?php ahashop_featured_quote(); ?>
	</div>
</article> <!-- end blockquote post -->
