<?php
/**
 * Sidebar template
 *
 * @package Ahashop
 */

if ( class_exists( 'Ahashop_Sidebar' ) && Ahashop_Sidebar::is_no_sidebar() ) {
	return;
}

$sidebar = 'sidebar-1';

if ( class_exists( 'WooCommerce' ) && ( is_cart() || is_checkout() || is_account_page() ) ) {
	$sidebar = 'shop-sidebar';
}

if ( ! is_active_sidebar( $sidebar ) ) {
	return;
}
?>
<!-- Sidebar -->
<aside id="secondary" class="widget-area sidebar" role="complementary">
	<?php dynamic_sidebar( $sidebar ); ?>
</aside> <!-- end sidebar -->
