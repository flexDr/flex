<?php
/**
 * Customize: Section Logo
 *
 * @package Ahashop
 */

/**
 * Register section logo settings.
 *
 * @param  WP_Customize $wp_customize WP_Customize object.
 */
function ahashop_customize_register_logo( $wp_customize ) {
	$wp_customize->add_section( 'logo', array(
		'title'       => esc_html__( 'Logo', 'ahashop' ),
		'priority'    => 20,
	) );

	$wp_customize->get_control( 'custom_logo' )->section = 'logo';

	$wp_customize->add_setting( 'desktop_logo_width', array(
		'default'           => ahashop_default( 'desktop_logo_width' ),
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'refresh',
	) );

	$wp_customize->add_control( 'desktop_logo_width', array(
		'label'       => esc_html__( 'Desktop logo width', 'ahashop' ),
		'section'     => 'logo',
		'type'        => 'text',
	) );

	$wp_customize->add_setting( 'desktop_header_padding', array(
		'default'           => ahashop_default( 'desktop_header_padding' ),
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'refresh',
	) );

	$wp_customize->add_control( 'desktop_header_padding', array(
		'label'       => esc_html__( 'Desktop header height', 'ahashop' ),
		'section'     => 'logo',
		'type'        => 'text',
	) );

	$wp_customize->add_setting( 'tablet_logo_width', array(
		'default'           => ahashop_default( 'tablet_logo_width' ),
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'refresh',
	) );

	$wp_customize->add_control( 'tablet_logo_width', array(
		'label'       => esc_html__( 'Ipad / Tablet logo width', 'ahashop' ),
		'section'     => 'logo',
		'type'        => 'text',
	) );

	$wp_customize->add_setting( 'tablet_header_padding', array(
		'default'           => ahashop_default( 'tablet_header_padding' ),
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'refresh',
	) );

	$wp_customize->add_control( 'tablet_header_padding', array(
		'label'       => esc_html__( 'Ipad / Tablet header height', 'ahashop' ),
		'section'     => 'logo',
		'type'        => 'text',
	) );

	$wp_customize->add_setting( 'mobile_logo_width', array(
		'default'           => ahashop_default( 'mobile_logo_width' ),
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'refresh',
	) );

	$wp_customize->add_control( 'mobile_logo_width', array(
		'label'       => esc_html__( 'Mobile logo width', 'ahashop' ),
		'section'     => 'logo',
		'type'        => 'text',
	) );

    $wp_customize->add_setting( 'mobile_header_padding', array(
        'default'           => ahashop_default( 'mobile_header_padding' ),
        'sanitize_callback' => 'esc_attr',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'mobile_header_padding', array(
        'label'       => esc_html__( 'Mobile header height', 'ahashop' ),
        'section'     => 'logo',
        'type'        => 'text',
    ) );

    /*Logo Text Enable*/
    $wp_customize->add_setting( 'enable_logo_text', array(
        'default'           => ahashop_default( 'enable_logo_text' ),
        'sanitize_callback' => 'absint',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'enable_logo_text', array(
        'label'       => esc_html__( 'Enable Logo Text', 'ahashop' ),
        'section'     => 'logo',
        'type'        => 'checkbox',
    ) );

    /*Logo Text*/
    $wp_customize->add_setting( 'header_logo_text', array(
        'default'           => ahashop_default( 'header_logo_text' ),
        'sanitize_callback' => 'esc_attr',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'header_logo_text', array(
        'label'       => esc_html__( 'Logo Text', 'ahashop' ),
        'section'     => 'logo',
        'type'        => 'text',
    ) );

    /*Logo Text Font Size*/
    $wp_customize->add_setting( 'logo_text_font_size', array(
        'default'           => ahashop_default( 'logo_text_font_size' ),
        'sanitize_callback' => 'esc_attr',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'logo_text_font_size', array(
        'label'       => esc_html__( 'Logo Font Size (Ex: 30px)', 'ahashop' ),
        'section'     => 'logo',
        'type'        => 'text',
    ) );

    // =========================================
    // Font Family
    // =========================================
    if(class_exists('AHASHOP_Customize_Control_Google_Font')){
        $wp_customize->add_setting( 'ahashop_logo_text_font_google', array(
            'transport'         => 'postMessage',
            'sanitize_callback' => 'ahashop_sanitize_font_family',
        ) );
        $wp_customize->add_control(
            new AHASHOP_Customize_Control_Google_Font(
                $wp_customize,
                'ahashop_logo_text_font_google',
                array(
                    'section'   => 'logo',
                    'label'     => __( 'Font Style', 'ahashop' ),
                    'fonts'     => ahashop_get_google_fonts(),
                )
            )
        );
    }
    $wp_customize->selective_refresh->add_partial( 'ahashop_logo_text_font_google', array(
        'selector'        => '#ahashop-style-inline-css-customizer',
        'render_callback' => '',
    ) );

    /*Logo Text Font Color*/
    $wp_customize->add_setting( 'logo_text_font_color', array(
        'default'           => '#000',
        'sanitize_callback' => 'esc_attr',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'logo_text_font_color',
            array(
                'label'      => esc_html__( 'Logo Font Color', 'ahashop' ),
                'section'    => 'logo',
            )
        )
    );

    /*Logo Text Font Type*/
    $wp_customize->add_setting( 'logo_text_font_type', array(
        'default'           => ahashop_default( 'logo_text_font_type' ),
		'sanitize_callback' => 'absint',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'logo_text_font_type', array(
        'label'       => esc_html__( 'Logo Text Type', 'ahashop' ),
        'section'     => 'logo',
        'type'        => 'select',
        'choices'   => array(
            'none'          => esc_html__( 'None', 'ahashop'),
            'outline'       => esc_html__( 'Logo Outline', 'ahashop'),
            'circle'        => esc_html__( 'Logo Circle', 'ahashop'),
        ),
    ) );
}
add_action( 'customize_register', 'ahashop_customize_register_logo' );


/**
 * Adds custom css for this section.
 *
 * @param  string $css Custom CSS.
 * @return string
 */
function ahashop_logo_customize_css( $css ) {

    /*Logo Text*/
    $body_font = get_theme_mod( 'ahashop_logo_text_font_google' );
    if ( is_array($body_font) && $body_font['family'] ) {
        $css .= ".logo-inner { font-family: {$body_font['family']};font-weight: {$body_font['fontWeight']}; }";
    }


    $value = trim( ahashop_option( 'logo_text_font_size' ) );
    if ( $value ) {
        $css .= ".logo-inner { font-size: {$value}; }";
    }
//    $value = trim( ahashop_option( 'logo_text_font_style' ) );
//    if ( $value ) {
//        $css .= ".logo-inner { font-style: {$value}; }";
//    }
    $value = trim( ahashop_option( 'logo_text_font_color' ) );
    if ( $value ) {
        $css .= ".logo-inner.none { color: {$value}; }.logo-inner.outline { color: {$value}; border-color: {$value}; }.logo-inner.circle { background-color: {$value}; border-color: {$value}; }";
    }



	/* Custom logo on mobile */
	$value = trim( ahashop_option( 'mobile_logo_width' ) );
	if ( $value ) {
		$css .= ".custom-logo, .logo, .logo-dark, .logo-inner, .logo-inner.outline, .logo-inner.circle { width: {$value}; }";
	}

	$value = trim( ahashop_option( 'mobile_header_padding' ) );
	if ( $value ) {
		$css .= ".logo-wrap, .navbar-header, .logo-inner, .logo-inner.outline, .logo-inner.circle { height: {$value}; }";
	}


	/* Custom logo on Ipad/Tablet */
	$css .= '@media (min-width: 768px) {';
	$value = trim( ahashop_option( 'tablet_logo_width' ) );
	if ( $value ) {
		$css .= ".custom-logo, .logo, .logo-dark, .logo-inner, .logo-inner.outline, .logo-inner.circle { width: {$value}; }";
	}

	$value = trim( ahashop_option( 'tablet_header_padding' ) );
	if ( $value ) {
		$css .= ".logo-wrap, .navbar-header, .logo-inner, .logo-inner.outline, .logo-inner.circle { height: {$value}; }";
	}
	$css .= '}';


	/* Custom logo on PC */
	$css .= '@media (min-width: 991px) {';
	$value = trim( ahashop_option( 'desktop_logo_width' ) );
	if ( $value ) {
		$css .= ".custom-logo, .logo, .logo-dark, .logo-inner, .logo-inner.outline, .logo-inner.circle { width: {$value}; }";
	}

	$value = trim( ahashop_option( 'desktop_header_padding' ) );
	if ( $value ) {
		$css .= ".logo-wrap, .navbar-header, .logo-inner, .logo-inner.outline, .logo-inner.circle { height: {$value}; }";
		$css .= ".navbar { min-height: calc({$value} + 47px); }";
	}
	$css .= '}';

	return $css;
}
add_filter( 'ahashop_inline_css', 'ahashop_logo_customize_css' );

/**
 * @param $font
 *
 * @return array
 */
function ahashop_sanitize_font_family($font) {
    if ($font && is_array($font)) {
        return $font;
    }

    return array(
        'family'     => '',
        'subsets'    => 'latin',
        'fontWeight' => '400',
    );
}
