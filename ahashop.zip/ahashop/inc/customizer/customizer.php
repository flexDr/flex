<?php
/**
 * Ahashop customizer
 *
 * @package Ahashop
 */

/**
 * Require settings.
 */
require_once get_parent_theme_file_path( 'inc/customizer/section-general.php' );
require_once get_parent_theme_file_path( 'inc/customizer/section-header.php' );
require_once get_parent_theme_file_path( 'inc/customizer/section-footer.php' );
require_once get_parent_theme_file_path( 'inc/customizer/section-blog.php' );
require_once get_parent_theme_file_path( 'inc/customizer/section-logo.php' );

/**
 * Bind JS handlers to instantly live-preview changes.
 */
function ahashop_customize_preview_js() {
	wp_enqueue_script( 'ahashop-customize-preview', get_theme_file_uri( '/assets/js/customize-preview.js' ), array( 'customize-preview' ), '1.0.0', true );
}
add_action( 'customize_preview_init', 'ahashop_customize_preview_js' );

/**
 * Load dynamic logic for the customizer controls area.
 */
function ahashop_customize_panels_js() {
	wp_enqueue_script( 'ahashop-libs', get_theme_file_uri( '/assets/babel/customize/libs.js' ), array(), '1.0.0', true );
	wp_enqueue_script( 'ahashop-core', get_theme_file_uri( '/assets/babel/customize/core.js' ), array(), '1.0.0', true );
	wp_enqueue_script( 'ahashop-customize-google-font', get_theme_file_uri( '/assets/babel/customize/google-font.js' ), array(), '1.0.0', true );
	wp_enqueue_script( 'ahashop-customize', get_theme_file_uri( '/assets/js/customize.js' ), array(), '1.0.0', true );
	wp_enqueue_script( 'ahashop-customize-controls', get_theme_file_uri( '/assets/js/customize-controls.js' ), array(), '1.0.0', true );
}
add_action( 'customize_controls_enqueue_scripts', 'ahashop_customize_panels_js' );

/**
 * Register customize settings.
 *
 * @param  object $wp_customize WP_Customize object.
 */
function ahashop_register_sidebar_settings( $wp_customize ) {

	$options = array(
		'sidebar-right' => esc_html__( 'Sidebar right', 'ahashop' ),
		'sidebar-left'  => esc_html__( 'Sidebar left', 'ahashop' ),
		'no-sidebar'    => esc_html__( 'No sidebar', 'ahashop' ),
	);

	$wp_customize->add_section(
		'sidebar',
		array(
			'title'    => esc_html__( 'Sidebar', 'ahashop' ),
			'priority' => 50,
		)
	);

	// Blog.
	$wp_customize->add_setting(
		'sidebar_layout',
		array(
			'default'           => ahashop_default( 'sidebar_layout' ),
			'transport'         => 'refresh',
			'sanitize_callback' => 'ahashop_sanitize_sidebar_layout',
		)
	);
	$wp_customize->add_control(
		'sidebar_layout',
		array(
			'label'   => esc_html__( 'Sidebar layout', 'ahashop' ),
			'section' => 'sidebar',
			'type'    => 'select',
			'choices' => $options,
		)
	);

	// Archive.
	$wp_customize->add_setting(
		'sidebar_archive_layout',
		array(
			'default'           => ahashop_default( 'sidebar_archive_layout' ),
			'transport'         => 'refresh',
			'sanitize_callback' => 'ahashop_sanitize_sidebar_layout',
		)
	);
	$wp_customize->add_control(
		'sidebar_archive_layout',
		array(
			'label'   => esc_html__( 'Sidebar layout for archive page', 'ahashop' ),
			'section' => 'sidebar',
			'type'    => 'select',
			'choices' => $options,
		)
	);

	// Single.
	$wp_customize->add_setting(
		'sidebar_single_layout',
		array(
			'default'           => ahashop_default( 'sidebar_single_layout' ),
			'transport'         => 'refresh',
			'sanitize_callback' => 'ahashop_sanitize_sidebar_layout',
		)
	);
	$wp_customize->add_control(
		'sidebar_single_layout',
		array(
			'label'   => esc_html__( 'Sidebar layout for single page', 'ahashop' ),
			'section' => 'sidebar',
			'type'    => 'select',
			'choices' => $options,
		)
	);

	// Page.
	$wp_customize->add_setting(
		'sidebar_page_layout',
		array(
			'default'           => ahashop_default( 'sidebar_page_layout' ),
			'transport'         => 'refresh',
			'sanitize_callback' => 'ahashop_sanitize_sidebar_layout',
		)
	);

	$wp_customize->add_control(
		'sidebar_page_layout',
		array(
			'label'   => esc_html__( 'Sidebar layout for page detail page', 'ahashop' ),
			'section' => 'sidebar',
			'type'    => 'select',
			'choices' => $options,
		)
	);
}
add_action( 'customize_register', 'ahashop_register_sidebar_settings' );

function ahashop_sanitize_sidebar_layout( $value ) {
	if ( ! in_array( $value, array( 'sidebar-right', 'sidebar-left', 'no-sidebar' ) ) ) {
		$value = ahashop_default( 'sidebar_layout' );
	}

	return $value;
}
