<?php
/**
 * Customize: Section Header
 *
 * @package Ahashop
 */

/**
 * Register section header settings.
 *
 * @param  WP_Customize $wp_customize WP_Customize object.
 */
function ahashop_customize_register_header( $wp_customize ) {
	// Register selective refresh partials.
//    $wp_customize->selective_refresh->add_partial( 'header_container', array(
//        'selector'        => '.top-bar',
//        'render_callback' => 'ahashop_top_bar',
//    ) );

    $wp_customize->selective_refresh->add_partial( 'show_top_bar', array(
        'selector'        => '.top-bar',
        'render_callback' => 'ahashop_top_bar',
    ) );

    $wp_customize->selective_refresh->add_partial( 'show_search_form', array(
        'selector'        => '.nav-search',
        'render_callback' => 'ahashop_header_search',
    ) );

    $wp_customize->selective_refresh->add_partial( 'show_minicart', array(
        'selector'        => '.nav-cart-wrap',
        'render_callback' => 'ahashop_header_mini_cart',
    ) );

    $wp_customize->selective_refresh->add_partial( 'show_notify', array(
        'selector'        => '.header-notify',
        'render_callback' => 'ahashop_notify',
    ) );

    $wp_customize->selective_refresh->add_partial( 'notify_text', array(
        'selector'        => '.notify-content',
        'render_callback' => 'ahashop_notify',
    ) );

	// Register section.
	$wp_customize->add_section( 'header', array(
		'title'       => esc_html__( 'Header', 'ahashop' ),
		'priority'    => 30,
	) );

	$wp_customize->add_setting( 'header_layout', array(
		'default'           => ahashop_default( 'header_layout' ),
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'refresh',
	) );

    $wp_customize->add_control( 'header_layout', array(
        'label'       => esc_html__( 'Header Layout', 'ahashop' ),
        'section'     => 'header',
        'type'        => 'select',
        'choices'   => array(
            'default'           => esc_html__( 'Default', 'ahashop'),
            'aside-menu'        => esc_html__( 'Logo aside Menu', 'ahashop'),
            'menu-on-logo'      => esc_html__( 'Menu on Logo', 'ahashop' ),
        ),
    ) );

    $wp_customize->add_setting( 'header_container', array(
        'default'           => ahashop_default( 'header_container' ),
        'sanitize_callback' => 'absint',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'header_container', array(
        'label'       => esc_html__( 'Header Container', 'ahashop' ),
        'section'     => 'header',
        'type'        => 'checkbox',
    ) );

    $wp_customize->add_setting( 'header_fixed', array(
        'default'           => ahashop_default( 'header_fixed' ),
        'sanitize_callback' => 'esc_attr',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'header_fixed', array(
        'label'       => esc_html__( 'Header fixed', 'ahashop' ),
        'section'     => 'header',
        'type'        => 'select',
        'choices'   => array(
            'fixed-none'          => esc_html__( 'None', 'ahashop'),
            'header-fixed'        => esc_html__( 'Fixed', 'ahashop'),
        ),
    ) );

    $wp_customize->add_setting( 'header_scroll_fixed', array(
        'default'           => ahashop_default( 'header_scroll_fixed' ),
        'sanitize_callback' => 'esc_attr',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'header_scroll_fixed', array(
        'label'       => esc_html__( 'Header fixed contain', 'ahashop' ),
        'section'     => 'header',
        'type'        => 'select',
        'description' => __('Just apply to Header layout default.', 'ahashop'),
        'choices'   => array(
            'normal'        => esc_html__( 'Menu + Search + Cart', 'ahashop'),
            'only-menu'     => esc_html__( 'Only Menu Show', 'ahashop' ),
        ),
    ) );

	$wp_customize->add_setting( 'show_top_bar', array(
		'sanitize_callback' => 'absint',
		'transport'         => 'postMessage',
	) );

	$wp_customize->add_control( 'show_top_bar', array(
		'label'       => esc_html__( 'Show top bar', 'ahashop' ),
		'section'     => 'header',
		'type'        => 'checkbox',
	) );

    $wp_customize->add_setting( 'show_search_form', array(
        'sanitize_callback' => 'absint',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( 'show_search_form', array(
        'label'       => esc_html__( 'Show search form', 'ahashop' ),
        'section'     => 'header',
        'type'        => 'checkbox',
    ) );

    $wp_customize->add_setting( 'show_minicart', array(
        'default'           => ahashop_default( 'show_minicart' ),
        'sanitize_callback' => 'absint',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( 'show_minicart', array(
        'label'       => esc_html__( 'Show Mini Cart', 'ahashop' ),
        'section'     => 'header',
        'type'        => 'checkbox',
    ) );

    $wp_customize->add_setting( 'show_notify', array(
        'sanitize_callback' => 'absint',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( 'show_notify', array(
        'label'       => esc_html__( 'Enable Notify', 'ahashop' ),
        'section'     => 'header',
        'type'        => 'checkbox',
    ) );

    /*Notify Text*/
    $wp_customize->add_setting( 'notify_text', array(
//        'default'           => ahashop_default( 'notify_text' ),
        'sanitize_callback' => 'wp_kses_post',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( 'notify_text', array(
        'label'       => esc_html__( 'Notify Text', 'ahashop' ),
        'section'     => 'header',
        'type'        => 'textarea',
    ) );

    $wp_customize->add_setting( 'notify_min_height', array(
        'sanitize_callback' => 'esc_attr',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'notify_min_height', array(
        'label'       => esc_html__( 'Notify Min Heigh (Exp:60px.)', 'ahashop' ),
        'section'     => 'header',
        'type'        => 'text',
    ) );

    $wp_customize->add_setting( 'notify_color', array(
        'default'           => '#fff',
        'sanitize_callback' => 'esc_attr',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'notify_color',
            array(
                'label'      => esc_html__( 'Notify Color', 'ahashop' ),
                'section'    => 'header',
            )
        )
    );

    $wp_customize->add_setting( 'notify_bg_color', array(
        'default'           => '#000',
        'sanitize_callback' => 'esc_attr',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'notify_bg_color',
            array(
                'label'      => esc_html__( 'Notify Background Color', 'ahashop' ),
                'section'    => 'header',
            )
        )
    );
}
add_action( 'customize_register', 'ahashop_customize_register_header' );


/**
 * Adds custom css for this section.
 *
 * @param  string $css Custom CSS.
 * @return string
 */
function ahashop_header_customize_css( $css ) {

    $value = trim( ahashop_option( 'notify_min_height' ) );
    if ( $value ) {
        $css .= "header .header-notify .notify-inner { min-height: {$value}; }";
    }

    $value = trim( ahashop_option( 'notify_color' ) );
    if ( $value ) {
        $css .= "header .header-notify .notify-content, header .header-notify .notify-content p, header .header-notify .notify-close:not(:hover) { color: {$value}; }";
    }

    $value = trim( ahashop_option( 'notify_bg_color' ) );
    if ( $value ) {
        $css .= "header .header-notify .notify-inner { background-color: {$value}; }";
    }


    return $css;
}
add_filter( 'ahashop_inline_css', 'ahashop_header_customize_css' );
