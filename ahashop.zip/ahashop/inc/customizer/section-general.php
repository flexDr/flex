<?php
/**
 * Customize: Section General
 *
 * @package Ahashop
 */

/**
 * Register section general settings.
 *
 * @param  WP_Customize $wp_customize WP_Customize object.
 */
function ahashop_customize_register_general( $wp_customize ) {
	$wp_customize->add_section( 'general', array(
		'title'       => esc_html__( 'General', 'ahashop' ),
		'priority'    => 20,
	) );

	$wp_customize->add_setting( 'show_preloader', array(
		'default'           => ahashop_default( 'show_preloader' ),
		'sanitize_callback' => 'absint',
		'transport'         => 'refresh',
	) );

	$wp_customize->add_control( 'show_preloader', array(
		'label'       => esc_html__( 'Show preloader', 'ahashop' ),
		'section'     => 'general',
		'type'        => 'checkbox',
	) );

	$wp_customize->add_setting( 'rtl', array(
		'default'           => ahashop_default( 'rtl' ),
		'sanitize_callback' => 'absint',
		'transport'         => 'refresh',
	) );

	$wp_customize->add_control( 'rtl', array(
		'label'       => esc_html__( 'RTL', 'ahashop' ),
		'section'     => 'general',
		'type'        => 'checkbox',
	) );

	$wp_customize->add_setting( 'slider_automation', array(
		'default'           => ahashop_default( 'slider_automation' ),
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'refresh',
	) );

	$wp_customize->add_control( 'slider_automation', array(
		'label'   => esc_html__( 'Slider automation', 'ahashop' ),
		'section' => 'general',
		'type'    => 'select',
		'choices' => array(
			'on'  => esc_html__( 'On', 'ahashop' ),
			'off' => esc_html__( 'Off', 'ahashop' ),
		),
	) );
}
add_action( 'customize_register', 'ahashop_customize_register_general' );
