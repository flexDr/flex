<?php
/**
 * WooCommerce add hooks
 *
 * @package Ahashop
 */

/* Archive product */
add_action( 'woocommerce_archive_description', 'ahashop_wc_product_category_banner', 10 );

add_action( 'woocommerce_after_shop_loop', 'ahashop_wc_archive_product_pagination_wrap_open', 6 );

add_action( 'woocommerce_after_shop_loop', 'woocommerce_result_count', 8 );

add_action( 'woocommerce_after_shop_loop', 'ahashop_wc_archive_product_pagination_wrap_close', 12 );

/* Content product */
add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_link_open', 5 );

add_action( 'woocommerce_before_shop_loop_item_title', 'ahashop_wc_template_loop_second_product_thumbnail', 10 );

add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_link_close', 20 );

add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 30 );

add_action( 'woocommerce_before_shop_loop_item_title', 'ahashop_wc_template_loop_product_stock', 30 );

add_action( 'woocommerce_before_shop_loop_item_title', 'ahashop_wc_template_loop_product_actions', 40 );

add_action( 'woocommerce_share', 'ahashop_entry_sharing' );

add_action( 'ahashop_template_product_thumbnail', 'ahashop_template_loop_product_thumbnail', 10 );

add_action( 'ahashop_show_product_sale_flash', 'ahashop_show_product_loop_sale_flash', 10 );

add_action( 'woocommerce_before_shop_loop', 'ahashop_woocommerce_before_shop_loop', 15 );

add_action( 'woocommerce_before_subcategory_title', 'ahashop_woocommerce_subcategory_thumbnail', 10 );

/**
 * Cart fragment
 *
 * @see ahashop_cart_link_fragment()
 */
if ( defined( 'WC_VERSION' ) && version_compare( WC_VERSION, '2.3', '>=' ) ) {
	add_filter( 'woocommerce_add_to_cart_fragments', 'ahashop_cart_link_fragment' );
} else {
	add_filter( 'add_to_cart_fragments', 'ahashop_cart_link_fragment' );
}

$tab_option = ahashop_option( 'product_tab_layout' );

if ( 'aside' === $tab_option ) {
	add_action( 'woocommerce_single_product_summary', 'woocommerce_output_product_data_tabs', 70 );
}

add_action( 'customize_preview_init', 'ahashop_customize_preview_init' );

add_action( 'product_cat_add_form_fields', 'ahashop_add_category_fields' );
add_action( 'product_cat_edit_form_fields', 'ahashop_edit_category_fields', 20 );
add_action( 'created_term', 'ahashop_save_category_fields', 20, 3 );
add_action( 'edit_term', 'ahashop_save_category_fields', 20, 3 );
