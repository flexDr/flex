<?php
/**
 * Remove WooCommerce hooks
 *
 * @package Ahashop
 */

/* Product archive page */
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );

remove_action( 'woocommerce_archive_description', 'woocommerce_taxonomy_archive_description', 10 );

/* Content product */
remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );

remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );

remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );

if ( ! ahashop_option( 'shop_add_to_cart' ) ) {
	remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
}

remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );

$tab_option = ahashop_option( 'product_tab_layout' );

if ( 'notabs' === $tab_option ) {
	add_filter( 'woocommerce_product_description_heading', '__return_false' );
	add_filter( 'woocommerce_product_additional_information_heading', '__return_false' );
}

if ( 'aside' === $tab_option ) {
	remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
}

remove_action( 'woocommerce_before_subcategory_title', 'woocommerce_subcategory_thumbnail', 10 );
