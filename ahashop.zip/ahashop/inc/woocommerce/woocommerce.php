<?php
/**
 * WooCommerce customizations
 *
 * @package Ahashop
 */

/**
 * Remove WooCommerce hooks.
 */
require_once get_template_directory() . '/inc/woocommerce/remove-hooks.php';

/**
 * Add WooCommerce hooks.
 */
require_once get_template_directory() . '/inc/woocommerce/add-hooks.php';

/**
 * Override WooCommerce template tags.
 */
require_once get_template_directory() . '/inc/woocommerce/template-tags.php';

if ( ! class_exists( 'WC_Product_Cat_List_Walker' ) ) {
	include_once( WC()->plugin_path() . '/includes/walkers/class-product-cat-list-walker.php' );
}

/**
 * Class Ahashop_WC_Product_Cat_List_Walker
 */
class Ahashop_WC_Product_Cat_List_Walker extends WC_Product_Cat_List_Walker {

	/**
	 * Start the element output.
	 *
	 * @see Walker::start_el()
	 * @since 2.1.0
	 *
	 * @param string $output Passed by reference. Used to append additional content.
	 * @param int $depth Depth of category in reference to parents.
	 * @param integer $current_object_id
	 */
	public function start_el( &$output, $cat, $depth = 0, $args = array(), $current_object_id = 0 ) {
		$output .= '<li class="cat-item cat-item-' . $cat->term_id;

		if ( $args['current_category'] == $cat->term_id ) {
			$output .= ' current-cat';
		}

		if ( $args['has_children'] && $args['hierarchical'] ) {
			$output .= ' cat-parent';
		}

		if ( $args['current_category_ancestors'] && $args['current_category'] && in_array( $cat->term_id, $args['current_category_ancestors'] ) ) {
			$output .= ' current-cat-parent';
		}

		$output .=  '"><a href="' . get_term_link( (int) $cat->term_id, $this->tree_type ) . '">' . $cat->name;

		if ( $args['show_count'] ) {
			$output .= ' <span class="count">(' . $cat->count . ')</span>';
		}

		$output .= '</a>';
	}
}

/**
 * Filter wc product categories widget args.
 *
 * @param  array $args Product categories widget args.
 * @return array
 */
function ahashop_wc_product_categories_widget_args( $args ) {
	$args['walker'] = new Ahashop_WC_Product_Cat_List_Walker();

	return $args;
}
add_filter( 'woocommerce_product_categories_widget_args', 'ahashop_wc_product_categories_widget_args' );

/**
 * Dequeue WooCommerce styles.
 *
 * @param  array $enqueue_styles Array of WooCommerce styles.
 * @return array
 */
function ahashop_wc_dequeue_styles( $enqueue_styles ) {
	// unset( $enqueue_styles['woocommerce-general'] );
	// unset( $enqueue_styles['woocommerce-layout'] );		// Remove the layout.
	// unset( $enqueue_styles['woocommerce-smallscreen'] );	// Remove the smallscreen optimisation.
	// return $enqueue_styles;
}
// add_filter( 'woocommerce_enqueue_styles', 'ahashop_wc_dequeue_styles' );

/**
 * Enqueue theme WooCommerce style.
 */
// function ahashop_wc_enqueue_styles() {
// 	wp_enqueue_style( 'ahashop-woocommerce', get_theme_file_uri( '/assets/css/woocommerce.css' ) );
// }
// add_action( 'wp_enqueue_scripts', 'ahashop_wc_enqueue_styles' );

/**
 * Filter WooCommerce breadcrumb default args.
 *
 * @param  array $args Breadcrumb args.
 * @return array
 */
function ahashop_wc_breadcrumb_defaults( $args ) {
	$args['delimiter'] = '';
	$args['wrap_before'] = '<ul class="woocommerce-breadcrumb breadcrumb" ' . ( is_single() ? 'itemprop="breadcrumb"' : '' ) . '>';
	$args['before'] = '<li>';
	$args['after'] = '</li>';

	return $args;
}
add_filter( 'woocommerce_breadcrumb_defaults', 'ahashop_wc_breadcrumb_defaults' );

/**
 * Register customizer settings for WooCommerce.
 *
 * @param  object $wp_customize WP_Customize object.
 */
function ahashop_wc_register_customizer_settings( $wp_customize ) {
	// Number of columns on mobile.
	$wp_customize->add_setting(
		'ahashop_woocommerce_catalog_columns_mobile',
		array(
			'default'              => 2,
			'type'                 => 'theme_mod',
			'capability'           => 'manage_woocommerce',
			'sanitize_callback'    => 'absint',
			'sanitize_js_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'ahashop_woocommerce_catalog_columns_mobile',
		array(
			'label'       => __( 'Products per row on mobile', 'ahashop' ),
			'description' => __( 'How many products should be shown per row on mobile?', 'ahashop' ),
			'section'     => 'woocommerce_product_catalog',
			'settings'    => 'ahashop_woocommerce_catalog_columns_mobile',
			'type'        => 'number',
			'input_attrs' => array(
				'min'  => wc_get_theme_support( 'product_grid::min_columns', 1 ),
				'max'  => wc_get_theme_support( 'product_grid::max_columns', '' ),
				'step' => 1,
			),
		)
	);

	$wp_customize->add_setting( 'product_image_hover_style', array(
		'default'           => ahashop_default( 'product_image_hover_style' ),
		'transport'         => 'refresh',
		'sanitize_callback' => 'sanitize_text_field',
		'type'              => 'theme_mod',
		'capability'        => 'manage_woocommerce',
	) );

	$wp_customize->add_control( 'product_image_hover_style', array(
		'label'   => esc_html__( 'Product Image Hover Style', 'ahashop' ),
		'section' => 'woocommerce_product_catalog',
		'type'    => 'select',
		'choices' => array(
			'none'      => esc_html__( 'None', 'ahashop' ),
			'zoom'      => esc_html__( 'Zoom out', 'ahashop' ),
			'secondary' => esc_html__( 'Secondary Image', 'ahashop' ),
		),
	) );

	$wp_customize->add_setting( 'product_show_hide_category', array(
		'default'           => ahashop_default( 'product_show_hide_category' ),
		'transport'         => 'refresh',
		'sanitize_callback' => 'sanitize_text_field',
		'type'              => 'theme_mod',
		'capability'        => 'manage_woocommerce',
	) );

	$wp_customize->add_control( 'product_show_hide_category', array(
		'label'   => esc_html__( 'Show/Hide Category', 'ahashop' ),
		'section' => 'woocommerce_product_catalog',
		'type'    => 'select',
		'choices' => array(
			'hide' => esc_html__( 'Hide', 'ahashop' ),
			'show' => esc_html__( 'Show', 'ahashop' ),
		),
	) );

	// Register section.
	$wp_customize->add_section( 'product_page', array(
		'title'    => esc_html__( 'Product Page', 'ahashop' ),
		'priority' => 40,
		'panel'    => 'woocommerce',
	) );

	$wp_customize->add_setting( 'product_photos', array(
		'default'           => ahashop_default( 'product_photos' ),
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'refresh',
	) );

	$wp_customize->add_control( 'product_photos', array(
		'label'   => esc_html__( 'Single Product Photos', 'ahashop' ),
		'section' => 'product_page',
		'type'    => 'select',
		'choices' => array(
			'gallery'      => esc_html__( 'Default', 'ahashop' ),
			'photos-stack' => esc_html__( 'Photos Stack', 'ahashop' ),
			'gallery-left' => esc_html__( 'Gallery Style Left', 'ahashop' ),
		),
	) );

	$wp_customize->add_setting( 'product_image_hover_zoom', array(
		'default'           => ahashop_default( 'product_image_hover_zoom' ),
		'sanitize_callback' => 'absint',
		'transport'         => 'refresh',
	) );

	$wp_customize->add_control( 'product_image_hover_zoom', array(
		'label'       => esc_html__( 'Gallery Photo', 'ahashop' ),
		'description' => __( 'Endable Product Image Hover Zoom?', 'ahashop' ),
		'section'     => 'product_page',
		'type'        => 'checkbox',
	) );

	$wp_customize->add_setting( 'product_tab_layout', array(
		'default'           => ahashop_default( 'product_tab_layout' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );

	$wp_customize->add_control( 'product_tab_layout', array(
		'label'       => esc_html__( 'Product Tabs', 'ahashop' ),
		'description' => __( 'Choose product tabs layout.', 'ahashop' ),
		'section'     => 'product_page',
		'type'        => 'select',
		'choices' => array(
			'default'  => esc_html__( 'Default', 'ahashop' ),
			'vertical' => esc_html__( 'Vertical', 'ahashop' ),
			'notabs'   => esc_html__( 'No tabs', 'ahashop' ),
			'aside'    => esc_html__( 'Aside', 'ahashop' ),
		),
	) );

	// Ajax add to cart.
	$wp_customize->add_setting( 'single_ajax_add_to_cart', array(
		'default'           => ahashop_default( 'single_ajax_add_to_cart' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
		'type'              => 'theme_mod',
		'capability'        => 'manage_woocommerce',
	) );

	$wp_customize->add_control( 'single_ajax_add_to_cart', array(
		'label'   => esc_html__( 'On/Off Ajax add to cart?', 'ahashop' ),
		'section' => 'product_page',
		'type'    => 'select',
		'choices' => array(
			'on'  => esc_html__( 'On', 'ahashop' ),
			'off' => esc_html__( 'Off', 'ahashop' ),
		),
	) );

	$wp_customize->add_setting( 'shop_add_to_cart', array(
		'default'              => ahashop_default( 'shop_add_to_cart' ),
		'sanitize_callback'    => 'absint',
		'transport'            => 'refresh',
	) );

	$wp_customize->add_control( 'shop_add_to_cart', array(
		'label'       => esc_html__( 'Show Add to cart button?', 'ahashop' ),
		'description' => esc_html__( 'You should save this setting and then refresh the page to see the change', 'ahashop' ),
		'section'     => 'woocommerce_product_catalog',
		'type'        => 'checkbox',
	) );

	$wp_customize->add_setting( 'woocommerce_shop_page_title', array(
		'default'           => ahashop_default( 'woocommerce_shop_page_title' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
		'type'              => 'theme_mod',
		'capability'        => 'manage_woocommerce',
	) );

	$wp_customize->add_control( 'woocommerce_shop_page_title', array(
		'label'   => esc_html__( 'Show/Hide Shop Page title?', 'ahashop' ),
		'section' => 'woocommerce_product_catalog',
		'type'    => 'select',
		'choices' => array(
			'show' => esc_html__( 'Show', 'ahashop' ),
			'hide' => esc_html__( 'Hide', 'ahashop' ),
		),
	) );

	// Register section.
	$wp_customize->add_section( 'product_category', array(
		'title' => esc_html__( 'Product Category', 'ahashop' ),
		'panel' => 'woocommerce',
	) );

	$wp_customize->add_setting( 'woocommerce_category_page_title', array(
		'default'           => ahashop_default( 'woocommerce_category_page_title' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
		'type'              => 'theme_mod',
		'capability'        => 'manage_woocommerce',
	) );

	$wp_customize->add_control( 'woocommerce_category_page_title', array(
		'label'   => esc_html__( 'Show/Hide Category Page title?', 'ahashop' ),
		'section' => 'product_category',
		'type'    => 'select',
		'choices' => array(
			'show' => esc_html__( 'Show', 'ahashop' ),
			'hide' => esc_html__( 'Hide', 'ahashop' ),
		),
	) );

	$wp_customize->add_setting( 'woocommerce_category_page_title_background', array(
		'default'           => ahashop_default( 'woocommerce_category_page_title_background' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
		'type'              => 'theme_mod',
		'capability'        => 'manage_woocommerce',
	) );

	$wp_customize->add_control( 'woocommerce_category_page_title_background', array(
		'label'   => esc_html__( 'On/Off Category Page Title Background?', 'ahashop' ),
		'section' => 'product_category',
		'type'    => 'select',
		'choices' => array(
			'on'  => esc_html__( 'On', 'ahashop' ),
			'off' => esc_html__( 'Off', 'ahashop' ),
		),
	) );
}
add_action( 'customize_register', 'ahashop_wc_register_customizer_settings' );

/**
 * Filter product review form arguments.
 *
 * @param  array $args Comment form args.
 * @return array
 */
function ahashop_wc_product_review_comment_form_args( $args ) {
	$args['class_submit'] = 'btn btn-md';
	$args['submit_button'] = '<button name="%1$s" type="submit" id="%2$s" class="%3$s"><span>%4$s</span></button>';

	return $args;
}
add_filter( 'woocommerce_product_review_comment_form_args', 'ahashop_wc_product_review_comment_form_args' );

if ( ! function_exists( 'ahashop_get_product_carousel_image_ids' ) ) {
	/**
	 * Get product carousel image ids.
	 *
	 * @return array
	 * @global object $product
	 */
	function ahashop_get_product_carousel_image_ids() {
		global $product;

		$attachment_ids = ahashop_wc_get_gallery_image_ids();

		if ( 'WC_Product_Variable' === get_class( $product ) ) {
			// Add variation images.
			$variations = $product->get_available_variations();

			foreach ( $variations as $variation ) {
				if ( ! empty( $variation['image_id'] ) ) {
					array_unshift( $attachment_ids, $variation['image_id'] );
				}
			}
		}

		if ( has_post_thumbnail() ) {
			array_unshift( $attachment_ids, get_post_thumbnail_id() );
		}

		$attachment_ids = array_unique( $attachment_ids );

		return apply_filters( 'ahashop_get_product_carousel_image_ids', $attachment_ids );
	}
}

/**
 * Filter single product gallery image html.
 *
 * @param  string $html          Image html.
 * @param  int    $attachment_id Attachment id.
 * @param  int    $product_id    Product id.
 * @param  string $image_class   Image classes.
 * @return string
 */
function ahashop_wc_single_product_image_thumbnail_html( $html, $attachment_id, $product_id, $image_class ) {
	$props = wc_get_product_attachment_props( $attachment_id );

	$html = sprintf(
		'<div class="gallery-cell">%s</div>',
		wp_get_attachment_image( $attachment_id, apply_filters( 'single_product_small_thumbnail_size', 'shop_thumbnail' ), 0, $props )
	);

	return $html;
}
add_filter( 'woocommerce_single_product_image_thumbnail_html', 'ahashop_wc_single_product_image_thumbnail_html', 10, 4 );

/**
 * Print clearfix element in the bottom of add to cart form.
 */
function ahashop_clearfix_after_add_to_cart() {
	echo '<div class="clear"></div>';
}
add_action( 'woocommerce_after_add_to_cart', 'ahashop_clearfix_after_add_to_cart', 99 );

/**
 * Hide product shop/category title.
 *
 * @param  boolean $show Show category title.
 * @return boolean
 */
function ahashop_hide_woocommerce_archive_title( $show ) {
	if ( is_product_category() ) {
		if ( 'hide' === ahashop_option( 'woocommerce_category_page_title' ) ) {
			$show = false;
		} else {
			$show = true;
		}
	}

	if ( is_shop() ) {
		if ( 'hide' === ahashop_option( 'woocommerce_shop_page_title' ) ) {
			$show = false;
		} else {
			$show = true;
		}
	}

	return $show;
}
add_filter( 'woocommerce_show_page_title', 'ahashop_hide_woocommerce_archive_title' );


/**
 * Adds custom css for shop layout.
 *
 * @param  string $css Custom CSS.
 * @return string
 */
function ahashop_woocommerce_shop_layout_css( $css ) {

	/* Custom logo on mobile */
	$col   = intval( ahashop_option( 'ahashop_woocommerce_catalog_columns_mobile' ) );
	$width = round( 100 / $col, 2 );

	$css .= <<<CSS
@media (max-width: 767px) {
	.woocommerce ul.products[class*="columns-"] li.product:nth-child(2n),
	.woocommerce-page ul.products[class*="columns-"] li.product:nth-child(2n) {
		float: left;
	}

	.woocommerce ul.products[class*="columns-"] li.product, .woocommerce-page ul.products[class*="columns-"] li.product {
		clear: none;
	}

	.woocommerce ul.products[class*=columns-] li.product,
	.woocommerce-page ul.products[class*=columns-] li.product {
		width: {$width}%;
	}

	.woocommerce ul.products[class*=columns-] li.product:nth-child({$col}n+1),
	.woocommerce-page ul.products[class*=columns-] li.product:nth-child({$col}n+1) {
		clear: both !important;
	}
}
CSS;

	return $css;
}
// add_filter( 'ahashop_inline_css', 'ahashop_woocommerce_shop_layout_css' );


/**
 * Process step nav.
 */
function ahashop_process_step_nav() {
	$current_id       = get_the_ID();
	$current_link     = get_permalink();
	$current_endpoint = WC()->query->get_current_endpoint();
	$step1            = '';
	$step2            = '';
	$step3            = '';

	if ( wc_get_page_id( 'cart' ) === $current_id ) {
		$step1 = ' current';
		$step2 = '';
		$step3 = '';
	} elseif ( wc_get_page_id( 'checkout' ) === $current_id ) {
		if ( get_option( 'woocommerce_checkout_order_received_endpoint' ) === $current_endpoint ) {
			$step1 = ' current';
			$step2 = ' current';
			$step3 = ' current';
		} else {
			$step1 = ' current';
			$step2 = ' current';
			$step3 = '';
		}
	}

	if ( wc_get_page_id( 'cart' ) !== $current_id && wc_get_page_id( 'checkout' ) !== $current_id ) {
		return;
	}

	?>
	<nav class="ahashop-process-step-nav">
		<a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="<?php echo esc_attr( $step1 ); ?>">
			<span class="step-number">1</span>
			<?php esc_html_e( 'Shopping Cart', 'ahashop' ); ?>
		</a>
		<span><svg viewBox="0 0 100 100"><path d="M 10,50 L 60,100 L 65,95 L 20,50  L 65,5 L 60,0 Z" class="arrow" transform="translate(100, 100) rotate(180) "></path></svg></span>
		<a href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="<?php echo esc_attr( $step2 ); ?>">
			<span class="step-number">2</span>
			<?php esc_html_e( 'Checkout details', 'ahashop' ); ?>
		</a>
		<span><svg viewBox="0 0 100 100"><path d="M 10,50 L 60,100 L 65,95 L 20,50  L 65,5 L 60,0 Z" class="arrow" transform="translate(100, 100) rotate(180) "></path></svg></span>
		<a href="#" class="no-click <?php echo esc_attr( $step3 ); ?>">
			<span class="step-number">3</span>
			<?php esc_html_e( 'Order Complete', 'ahashop' ); ?>
		</a>
	</nav>
	<?php
}
add_action( 'ahashop_before_single', 'ahashop_process_step_nav' );



function ahashop_woocommerce_grouped_product_columns( $args ) {
	array_unshift( $args, 'thumb' );

	return $args;
}
add_filter( 'woocommerce_grouped_product_columns', 'ahashop_woocommerce_grouped_product_columns' );

function ahashop_woocommerce_grouped_product_list_before_thumb( $value, $grouped_product_child ) {
	$html = get_the_post_thumbnail( $grouped_product_child->get_id() );

	$html .= $value;
	return $html;
}
add_filter( 'woocommerce_grouped_product_list_column_thumb', 'ahashop_woocommerce_grouped_product_list_before_thumb', 10, 2 );
