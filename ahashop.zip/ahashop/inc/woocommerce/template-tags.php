<?php
/**
 * Ahashop template tags
 *
 * @package Ahashop
 */

/**
 * Show the product title in the product loop. By default this is an H3.
 */
function woocommerce_template_loop_product_title() {
	?>
	<h3><a class="product-title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
	<?php
}

if ( ! function_exists( 'ahashop_wc_template_loop_product_actions' ) ) {
	/**
	 * Show product actions.
	 */
	function ahashop_wc_template_loop_product_actions() {
		global $yith_woocompare;
		?>
		<div class="product-actions">
			<?php if ( class_exists( 'YITH_Woocompare' ) ) : ?>
				<a href="<?php echo esc_url( add_query_arg( array( 'iframe' => 'true' ), $yith_woocompare->obj->view_table_url() ) ); ?>" class="product-add-to-compare compare" data-toggle="tooltip" data-placement="bottom" data-product_id="<?php the_ID(); ?>"><i class="fa fa-exchange"></i></a>
			<?php endif; ?>

			<?php if ( class_exists( 'YITH_WCWL' ) ) : ?>
				<?php echo do_shortcode( '[yith_wcwl_add_to_wishlist icon="fab fa-heart"]' ); ?>
			<?php endif; ?>
		</div>

		<a href="<?php the_permalink(); ?>" class="product-quickview"><?php esc_html_e( 'Quick View', 'ahashop' ); ?></a>
		<?php
	}
}

if ( ! function_exists( 'ahashop_wc_template_loop_product_stock' ) ) {
	/**
	 * Print out of stock.
	 */
	function ahashop_wc_template_loop_product_stock() {
		global $product;

		if ( ! $product->managing_stock() && ! $product->is_in_stock() ) {
			?>
			<span class="sold-out valign"><?php esc_html_e( 'out of stock', 'ahashop' ); ?></span>
			<?php
		}
	}
}

if ( ! function_exists( 'ahashop_wc_get_gallery_image_attachment_ids' ) ) {
	/**
	 * Get gallery image ids.
	 *
	 * @return array
	 */
	function ahashop_wc_get_gallery_image_ids() {
		global $product;

		if ( method_exists( $product, 'get_gallery_image_ids' ) ) {
			return $product->get_gallery_image_ids();
		}

		return $product->get_gallery_attachment_ids();
	}
}

/**
 * Display the second thumbnail.
 */
function ahashop_wc_template_loop_second_product_thumbnail() {
	$attachment_ids = ahashop_wc_get_gallery_image_ids();

	if ( 1 > count( $attachment_ids ) || 'secondary' !== ahashop_option( 'product_image_hover_style' ) ) {
		return;
	}

	$image_size = apply_filters( 'single_product_archive_thumbnail_size', 'ahashop-product' );

	$secondary_image_id = apply_filters( 'ahashop_wc_product_image_hover', $attachment_ids[0] );

	$classes = 'back-img';

	echo wp_get_attachment_image( $secondary_image_id, $image_size, '', array( 'class' => $classes ) );
}

/**
 * Print archive product pagination wrap open tag.
 */
function ahashop_wc_archive_product_pagination_wrap_open() {
	echo '<div class="pagination-wrap clearfix">';
}

/**
 * Print archive product pagination wrap close tag.
 */
function ahashop_wc_archive_product_pagination_wrap_close() {
	echo '</div>';
}

/**
 * Output the product image before the single product summary.
 *
 * @subpackage	Product
 */
function woocommerce_show_product_images() {
	/* wc_get_template( 'single-product/product-image.php' ); */
	$ahashop_product_photos = ahashop_option( 'product_photos' );
	if ( is_product() && 'photos-stack' === $ahashop_product_photos ) {
		wc_get_template( 'single-product/product-image-stack.php' );
	} else {
		wc_get_template( 'single-product/product-image-carousel.php' );
	}
}

if ( ! function_exists( 'ahashop_wc_product_category_banner' ) ) {
	/**
	 * Display product category banner.
	 */
	function ahashop_wc_product_category_banner() {
		if ( ! is_product_category() || 'off' === ahashop_option( 'woocommerce_category_page_title_background' ) ) {
			return;
		}

		$cat           = get_queried_object();
		$background_id = get_term_meta( $cat->term_id, 'thumbnail_id', true );
		$image         = wp_get_attachment_url( $background_id );
		?>
		<!-- Banner -->
		<div class="banner-wrap relative">
			<?php
			if ( $image ) {
				echo '<img src="' . esc_url( $image ) . '" alt="' . esc_attr( $cat->name ) . '" />';
			}
			?>
			<div class="hero-holder text-center right-align">
				<div class="hero-lines mb-0">
					<h1 class="hero-heading"><?php echo esc_html( $cat->name ); ?></h1>
					<h4 class="hero-subheading"><?php echo esc_html( $cat->description ); ?></h4>
				</div>
			</div>
			<div class="show-mobile" style="background-image: url(<?php echo esc_url( esc_url( $image ) ); ?>);"></div>
		</div>
		<?php
	}
}

if ( ! function_exists( 'ahashop_template_loop_product_thumbnail' ) ) {
	function ahashop_template_loop_product_thumbnail(){
		the_post_thumbnail('woocommerce_thumbnail', array('class' => 'attachment-woocommerce_thumbnail size-woocommerce_thumbnail'));

	}
}

if ( ! function_exists( 'ahashop_show_product_loop_sale_flash' ) ) {
	function ahashop_show_product_loop_sale_flash(){

		global $post, $product;

		?>
		<?php if ( $product->is_on_sale() ) : ?>
			<?php
			$ahashop_price_sale = (int)($product->get_sale_price());
			$ahashop_price    = (int)($product->get_regular_price());
			if( $ahashop_price != 0 ){
				$ahashop_percent  = round(100 - ($ahashop_price_sale / $ahashop_price * 100));
			}else{
				$ahashop_percent = 0;
			}
			$ahashop_percent_sale = ceil($ahashop_percent);

			echo apply_filters( 'woocommerce_sale_flash', '<span class="onsale">' . esc_html__( 'Sale ', 'ahashop' ) . $ahashop_percent_sale . esc_html__('%','ahashop') . '</span>', $post, $product );
			?>
		<?php endif;
	}
}

if ( ! function_exists( 'ahashop_cart_link' ) ) {
	/**
	 * Cart Link
	 * Displayed a link to the cart including the number of items present and the cart total
	 *
	 * @return void
	 */
	function ahashop_cart_link() {
		?>
		<a class="cart-contents" href="<?php echo esc_url( wc_get_cart_url() ); ?>" title="<?php esc_attr_e( 'View your shopping cart', 'ahashop' ); ?>">
			<span>
				<?php
				printf(
				/* translators: cart total */
					esc_html__( 'Cart / %s', 'ahashop' ),
					wp_kses( WC()->cart->get_cart_subtotal(), array() )
				);
				?>
			</span>
		</a>
		<?php
	}
}

if ( ! function_exists( 'ahashop_nav_cart_icon' ) ) {
	/**
	 * Cart Link
	 * Displayed a link to the cart including the number of items present and the cart total
	 *
	 * @return void
	 */
	function ahashop_nav_cart_icon() {
		?>
		<a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="nav-cart-icon"><?php echo absint( WC()->cart->get_cart_contents_count() ); ?></a>
		<?php
	}
}

if ( ! function_exists( 'ahashop_cart_link_fragment' ) ) {
	/**
	 * Cart Fragments
	 * Ensure cart contents update when products are added to the cart via AJAX
	 *
	 * @param  array $fragments Fragments to refresh via AJAX.
	 * @return array            Fragments to refresh via AJAX
	 */
	function ahashop_cart_link_fragment( $fragments ) {
		global $woocommerce;

		ob_start();
		ahashop_cart_link();
		$fragments['a.cart-contents'] = ob_get_clean();

		ob_start();
		ahashop_nav_cart_icon();
		$fragments['a.nav-cart-icon'] = ob_get_clean();

		return $fragments;
	}
}

if ( ! function_exists( 'ahashop_get_video_url' ) ) {
	/**
	 * Get video url.
	 *
	 * @param  string $video_url raw video url by user input.
	 * @return string            video url.
	 */
	function ahashop_get_video_url( $video_url ) {
		$video_url = esc_url( $video_url );

		if ( strpos( $video_url, 'youtube' ) || strpos( $video_url, 'youtu.be' ) ) {

			preg_match( '/^.*(?:youtu\.be\/|youtube(?:-nocookie)?\.com\/(?:(?:watch)?\?(?:.*&)?vi?=|(?:embed|v|vi|user)\/))([^\?&\"\'>]+)/', $video_url, $matches );

			$video_url = 'https://www.youtube.com/watch?v=' . $matches[1];

		} elseif ( strpos( $video_url, 'vimeo' ) ) {

			preg_match( '/^.*vimeo\.com\/(?:[a-z]*\/)*([‌​0-9]{6,11})[?]?.*/', $video_url, $matches );

			$video_url = 'http://vimeo.com/' . $matches[1];

		} else {

			$video_url = '';

		}

		return $video_url;
	}
}

/**
 * Category background fields.
 */
function ahashop_add_category_fields() {
	?>
	<div class="form-field term-background-wrap">
		<label><?php esc_html_e( 'Featured', 'ahashop' ); ?></label>
		<div id="product_cat_background" style="float: left; margin-right: 10px;"><img src="<?php echo esc_url( wc_placeholder_img_src() ); ?>" width="60px" height="60px" /></div>
		<div style="line-height: 60px;">
			<input type="hidden" id="product_cat_background_id" name="product_cat_background_id" />
			<button type="button" class="ahashop_upload_image_button button"><?php esc_html_e( 'Upload/Add image', 'ahashop' ); ?></button>
			<button type="button" class="ahashop_remove_image_button button"><?php esc_html_e( 'Remove image', 'ahashop' ); ?></button>
		</div>
		<script type="text/javascript">

			// Only show the "remove image" button when needed
			if ( ! jQuery( '#product_cat_background_id' ).val() ) {
				jQuery( '.ahashop_remove_image_button' ).hide();
			}

			// Uploading files
			var file_frame2;

			jQuery( document ).on( 'click', '.ahashop_upload_image_button', function( event ) {

				event.preventDefault();

				// If the media frame already exists, reopen it.
				if ( file_frame2 ) {
					file_frame2.open();
					return;
				}

				// Create the media frame.
				file_frame2 = wp.media.frames.downloadable_file = wp.media({
					title: '<?php esc_html_e( 'Choose an image', 'ahashop' ); ?>',
					button: {
						text: '<?php esc_html_e( 'Use image', 'ahashop' ); ?>'
					},
					multiple: false
				});

				// When an image is selected, run a callback.
				file_frame2.on( 'select', function() {
					var background            = file_frame2.state().get( 'selection' ).first().toJSON();
					var attachment_background = background.sizes.background || background.sizes.full;

					jQuery( '#product_cat_background_id' ).val( background.id );
					jQuery( '#product_cat_background' ).find( 'img' ).attr( 'src', attachment_background.url );
					jQuery( '.ahashop_remove_image_button' ).show();
				});

				// Finally, open the modal.
				file_frame2.open();
			});

			jQuery( document ).on( 'click', '.ahashop_remove_image_button', function() {
				jQuery( '#product_cat_background' ).find( 'img' ).attr( 'src', '<?php echo esc_js( wc_placeholder_img_src() ); ?>' );
				jQuery( '#product_cat_background_id' ).val( '' );
				jQuery( '.ahashop_remove_image_button' ).hide();
				return false;
			});

			jQuery( document ).ajaxComplete( function( event, request, options ) {
				if ( request && 4 === request.readyState && 200 === request.status
					&& options.data && 0 <= options.data.indexOf( 'action=add-tag' ) ) {

					var res = wpAjax.parseAjaxResponse( request.responseXML, 'ajax-response' );
					if ( ! res || res.errors ) {
						return;
					}
					// Clear Background fields on submit
					jQuery( '#product_cat_background' ).find( 'img' ).attr( 'src', '<?php echo esc_js( wc_placeholder_img_src() ); ?>' );
					jQuery( '#product_cat_background_id' ).val( '' );
					jQuery( '.ahashop_remove_image_button' ).hide();
					// Clear Display type field on submit
					jQuery( '#display_type' ).val( '' );
					return;
				}
			} );

		</script>
		<div class="clear"></div>
	</div>
	<?php
}

/**
 * Edit category background field.
 *
 * @param mixed $term Term (category) being edited.
 */
function ahashop_edit_category_fields( $term ) {

	$display_type  = get_term_meta( $term->term_id, 'display_type', true );
	$background_id = absint( get_term_meta( $term->term_id, 'background_id', true ) );

	if ( $background_id ) {
		$image = wp_get_attachment_thumb_url( $background_id );
	} else {
		$image = wc_placeholder_img_src();
	}
	?>
	<tr class="form-field term-background-wrap">
		<th scope="row" valign="top"><label><?php esc_html_e( 'Featured', 'ahashop' ); ?></label></th>
		<td>
			<div id="product_cat_background" style="float: left; margin-right: 10px;"><img src="<?php echo esc_url( $image ); ?>" width="60px" height="60px" /></div>
			<div style="line-height: 60px;">
				<input type="hidden" id="product_cat_background_id" name="product_cat_background_id" value="<?php echo esc_attr( $background_id ); ?>" />
				<button type="button" class="ahashop_upload_image_button button"><?php esc_html_e( 'Upload/Add image', 'ahashop' ); ?></button>
				<button type="button" class="ahashop_remove_image_button button"><?php esc_html_e( 'Remove image', 'ahashop' ); ?></button>
			</div>
			<script type="text/javascript">

				// Only show the "remove image" button when needed
				if ( '0' === jQuery( '#product_cat_background_id' ).val() ) {
					jQuery( '.ahashop_remove_image_button' ).hide();
				}

				// Uploading files
				var file_frame2;

				jQuery( document ).on( 'click', '.ahashop_upload_image_button', function( event ) {

					event.preventDefault();

					// If the media frame already exists, reopen it.
					if ( file_frame2 ) {
						file_frame2.open();
						return;
					}

					// Create the media frame.
					file_frame2 = wp.media.frames.downloadable_file = wp.media({
						title: '<?php esc_html_e( 'Choose an image', 'ahashop' ); ?>',
						button: {
							text: '<?php esc_html_e( 'Use image', 'ahashop' ); ?>'
						},
						multiple: false
					});

					// When an image is selected, run a callback.
					file_frame2.on( 'select', function() {
						var background            = file_frame2.state().get( 'selection' ).first().toJSON();
						var attachment_background = background.sizes.background || background.sizes.full;

						jQuery( '#product_cat_background_id' ).val( background.id );
						jQuery( '#product_cat_background' ).find( 'img' ).attr( 'src', attachment_background.url );
						jQuery( '.ahashop_remove_image_button' ).show();
					});

					// Finally, open the modal.
					file_frame2.open();
				});

				jQuery( document ).on( 'click', '.ahashop_remove_image_button', function() {
					jQuery( '#product_cat_background' ).find( 'img' ).attr( 'src', '<?php echo esc_js( wc_placeholder_img_src() ); ?>' );
					jQuery( '#product_cat_background_id' ).val( '' );
					jQuery( '.ahashop_remove_image_button' ).hide();
					return false;
				});

			</script>
			<div class="clear"></div>
		</td>
	</tr>
	<?php
}

/**
 * Save category fields
 *
 * @param mixed  $term_id Term ID being saved.
 * @param mixed  $tt_id Term taxonomy ID.
 * @param string $taxonomy Taxonomy slug.
 */
function ahashop_save_category_fields( $term_id, $tt_id = '', $taxonomy = '' ) {
	if ( isset( $_POST['product_cat_background_id'] ) && 'product_cat' === $taxonomy ) { // WPCS: CSRF ok, input var ok.
		update_term_meta( $term_id, 'background_id', absint( $_POST['product_cat_background_id'] ) ); // WPCS: CSRF ok, input var ok.
	}
}

function ahashop_woocommerce_before_shop_loop() {
	?>
	<div class="shop-sidebar-toggle"><?php esc_html_e( 'Filter', 'ahashop' ); ?></div>
	<?php
}

function ahashop_woocommerce_subcategory_thumbnail( $category ) {
	$small_thumbnail_size = apply_filters( 'subcategory_archive_thumbnail_size', 'woocommerce_thumbnail' );
	$dimensions           = wc_get_image_size( $small_thumbnail_size );
	$thumbnail_id         = get_term_meta( $category->term_id, 'background_id', true );

	if ( $thumbnail_id ) {
		$image = wp_get_attachment_image_src( $thumbnail_id, $small_thumbnail_size );
		if ( $image ) {
			$image = $image[0];
		}
		$image_srcset = function_exists( 'wp_get_attachment_image_srcset' ) ? wp_get_attachment_image_srcset( $thumbnail_id, $small_thumbnail_size ) : false;
		$image_sizes  = function_exists( 'wp_get_attachment_image_sizes' ) ? wp_get_attachment_image_sizes( $thumbnail_id, $small_thumbnail_size ) : false;
	} else {
		$image        = wc_placeholder_img_src();
		$image_srcset = false;
		$image_sizes  = false;
	}

	if ( $image ) {
		// Prevent esc_url from breaking spaces in urls for image embeds.
		// Ref: https://core.trac.wordpress.org/ticket/23605.
		$image = str_replace( ' ', '%20', $image );

		// Add responsive image markup if available.
		if ( $image_srcset && $image_sizes ) {
			echo '<img src="' . esc_url( $image ) . '" alt="' . esc_attr( $category->name ) . '" width="' . esc_attr( $dimensions['width'] ) . '" height="' . esc_attr( $dimensions['height'] ) . '" srcset="' . esc_attr( $image_srcset ) . '" sizes="' . esc_attr( $image_sizes ) . '" />';
		} else {
			echo '<img src="' . esc_url( $image ) . '" alt="' . esc_attr( $category->name ) . '" width="' . esc_attr( $dimensions['width'] ) . '" height="' . esc_attr( $dimensions['height'] ) . '" />';
		}
	}
}
