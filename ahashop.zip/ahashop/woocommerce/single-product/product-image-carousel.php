<?php
/**
 * Single Product Image
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/product-image.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @author      WooThemes
 * @package     WooCommerce/Templates
 * @version     2.6.3
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $post, $product;

$attachment_ids = ahashop_get_product_carousel_image_ids();

$product_photos = ahashop_option( 'product_photos' );

$product_video = get_post_meta( $post->ID, '_product_video', true );

if ( ! $attachment_ids ) {
	return;
}
?>
<div class="images">
	<div class="product-gallery-main">
		<?php woocommerce_show_product_sale_flash(); ?>
		<div class="flickity flickity-slider-wrap mfp-hover" id="gallery-main">

			<?php
			foreach ( $attachment_ids as $attachment_id ) :
				$thumbnail_full = wp_get_attachment_image_url( $attachment_id, 'full' );
				?>

				<div class="gallery-cell" data-id="<?php echo intval( $attachment_id ); ?>" data-thumb="<?php echo esc_url( $thumbnail_full ); ?>">
					<a href="<?php echo esc_url( $thumbnail_full ); ?>" class="lightbox-img woocommerce-main-image">
						<?php echo wp_get_attachment_image( $attachment_id, 'shop_single' ); ?>
						<i class="fas fa-expand-alt"></i>
					</a>
				</div>

				<?php
			endforeach;
			?>

		</div> <!-- end gallery main -->

		<?php if ( $product_video ) : ?>
		<a class="product-video-lightbox" href="<?php echo esc_url( ahashop_get_video_url( $product_video ) ); ?>"></a>
		<?php endif; ?>
	</div>

	<div class="product-gallery-nav">
		<?php do_action( 'woocommerce_product_thumbnails' ); ?>
	</div>
</div>
