=== Ahashop ===
Contributors: minWP
Tags: one-column, two-columns, left-sidebar, right-sidebar, grid-layout, sticky-post, theme-options, custom-logo, featured-images, post-formats, translation-ready, e-commerce, threaded-comments
Requires at least: 4.7
Tested up to: WordPress 5.1
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

AhaShop - an online fashion clothing store WordPress theme only targets at small and medium businesses.

== Description ==
AhaShop - an online fashion clothing store WordPress theme only targets at small and medium businesses. The theme also suitable for any kind of online store website like clothes man, clothes women, fashion kids, shoes, watches, jewelry, handbags & wallets, accessories…. etc.
