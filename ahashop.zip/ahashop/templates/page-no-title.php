<?php
/**
 * Template Name: Page No Title
 * Template Post Type: page
 *
 * @package Ahashop
 */

get_header();
?>
	<div class="post-content mb-50" id="main" role="main">

		<?php do_action( 'ahashop_before_single' ); ?>

		<?php while ( have_posts() ) : the_post(); ?>

			<?php get_template_part( 'template-parts/loop/content', 'page-no-title' ); ?>

		<?php endwhile; ?>

		<?php do_action( 'ahashop_after_single' ); ?>

	</div>
<?php
get_sidebar();
get_footer();
